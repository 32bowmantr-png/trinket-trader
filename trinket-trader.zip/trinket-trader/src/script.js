let gameState = {
  money: 50,
  day: 1,
  inventory: {},
  blackMarketPurchasesToday: 0,
  gameRunning: true,
  usedDarkMarket: false
};

const trinkets = [
  "Obsidian Relic", "Crimson Locket", "Encrypted Chip", "Glass Shard",
  "Forgotten Coin", "Ivory Skull", "Blood Ruby", "Rust Key",
  "Ancient Ring", "Smoked Pendant", "Twisted Watch", "Cursed Figurine"
];

function playBeep(type = 1) {
  const beep = document.getElementById(type === 1 ? 'beep1' : 'beep2');
  beep.currentTime = 0;
  beep.play();
}

function updateDisplay() {
  document.getElementById('money').textContent = `$${gameState.money}`;
  document.getElementById('day').textContent = gameState.day;
  document.getElementById('blackMarketPurchases').textContent = `${gameState.blackMarketPurchasesToday}/3`;
  const inventoryGrid = document.getElementById('inventoryGrid');

  if (Object.keys(gameState.inventory).length === 0) {
    inventoryGrid.innerHTML = '<div class="inventory-item"><div class="item-name">None</div><div class="item-count">Awaiting goods</div></div>';
  } else {
    inventoryGrid.innerHTML = '';
    for (const [item, count] of Object.entries(gameState.inventory)) {
      const div = document.createElement('div');
      div.className = 'inventory-item';
      div.innerHTML = `<div class="item-name">${item}</div><div class="item-count">${count}</div>`;
      inventoryGrid.appendChild(div);
    }
  }

  const btn = id => document.getElementById(id);
  const money = gameState.money;
  btn('blackMarketBtn').classList.toggle('disabled', gameState.blackMarketPurchasesToday >= 3 || money < 8 || !gameState.gameRunning);
  btn('ticketBtn').classList.toggle('disabled', money < 1000 || !gameState.gameRunning);
}

function addEvent(msg, type = 'normal') {
  const container = document.getElementById('eventsContainer');
  const div = document.createElement('div');
  div.className = `log-entry log-${type}`;
  div.textContent = `[Day ${gameState.day}] ${msg}`;
  container.insertBefore(div, container.firstChild);
  while (container.children.length > 10) container.removeChild(container.lastChild);
  playBeep(type === 'danger' ? 2 : 1);
}

function getRandomTrinket() {
  return trinkets[Math.floor(Math.random() * trinkets.length)];
}

function addToInventory(item) {
  gameState.inventory[item] = (gameState.inventory[item] || 0) + 1;
}

function checkDarkMarketExposure() {
  if (!gameState.gameRunning) return;
  if (gameState.usedDarkMarket && gameState.money >= 2000) {
    addEvent("Dark market exposure detected. Authorities trace transactions and apprehend operator.", 'danger');
    gameState.gameRunning = false;
    updateDisplay();
  }
}

function buyFromNormalMarket() {
  if (!gameState.gameRunning || gameState.money < 15) return;
  gameState.money -= 15;
  const item = getRandomTrinket();
  addToInventory(item);
  addEvent(`Acquired ${item} from local exchange (-$15).`, 'normal');
  updateDisplay();
  checkDarkMarketExposure();
}

function buyFromBlackMarket() {
  if (!gameState.gameRunning || gameState.money < 8 || gameState.blackMarketPurchasesToday >= 3) return;
  gameState.money -= 8;
  gameState.blackMarketPurchasesToday++;
  gameState.usedDarkMarket = true;
  const item = getRandomTrinket();
  addToInventory(item);
  addEvent(`Black acquisition: ${item} (-$8).`, 'warning');
  updateDisplay();
  checkDarkMarketExposure();
}

function buyFromIllegalMarket() {
  if (!gameState.gameRunning || gameState.money < 500) return;
  addEvent("STING DETECTED. Authorities inbound.", 'danger');
  gameState.gameRunning = false;
  updateDisplay();
}

function sellAtAuction() {
  if (!gameState.gameRunning) return;
  const keys = Object.keys(gameState.inventory);
  if (keys.length === 0) return addEvent("No merchandise to auction.", 'warning');
  const item = keys[Math.floor(Math.random() * keys.length)];
  const profit = Math.floor(Math.random() * 5) + 10;
  gameState.money += profit;
  gameState.inventory[item]--;
  if (gameState.inventory[item] <= 0) delete gameState.inventory[item];
  addEvent(`Sold ${item} for $${profit}.`, 'success');
  updateDisplay();
  checkDarkMarketExposure();
}

function buyTicket() {
  if (!gameState.gameRunning || gameState.money < 1000) return;
  addEvent("Extraction successful. Awaiting manual reset.", 'success');
  gameState.gameRunning = false;
  updateDisplay();
}

function restartGame() {
  gameState = { money: 50, day: 1, inventory: {}, blackMarketPurchasesToday: 0, gameRunning: true, usedDarkMarket: false };
  document.getElementById('eventsContainer').innerHTML = '<div class="log-entry log-normal">[SYSTEM] Operation reinitialized.</div>';
  updateDisplay();
  playBeep();
}

function randomEvent() {
  if (!gameState.gameRunning) return;
  if (Math.random() < 0.15) {
    addEvent("Tax audit detected (-$5).", 'warning');
    gameState.money = Math.max(0, gameState.money - 5);
    updateDisplay();
    checkDarkMarketExposure();
  }
  if (Math.random() < 0.1) {
    addEvent("Surveillance sweep initiated...", 'warning');
    if (Math.random() < 0.05) {
      addEvent("Contraband discovered. Operation terminated.", 'danger');
      gameState.gameRunning = false;
      updateDisplay();
    } else addEvent("Sweep cleared. No trace found.", 'normal');
  }
}

setInterval(() => {
  if (!gameState.gameRunning) return;
  gameState.day++;
  gameState.blackMarketPurchasesToday = 0;
  randomEvent();
  updateDisplay();
}, 60000);

updateDisplay();


